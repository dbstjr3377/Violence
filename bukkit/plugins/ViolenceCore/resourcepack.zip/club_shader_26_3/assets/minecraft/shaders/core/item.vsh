#version 330
#extension GL_ARB_separate_shader_objects : require
// VIOLENCE: 바닐라 26.3 원본 + 처치 흑백 깜빡임(violence_flash.glsl). 바뀐 줄에 "VIOLENCE" 표시

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:violence_flash.glsl>  // VIOLENCE
#include <minecraft:violence_skin.glsl>  // VIOLENCE: 공격 인형 무기 (1인칭 자기 인형 숨김, 밝기)

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
layout(location = 8) flat out float violencePersp;  // VIOLENCE: 월드(원근)면 1, GUI(정사영)면 0
layout(location = 7) out vec2 violenceFlash;  // VIOLENCE: (깜빡임 여부, 대신 쓸 밝기)
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

void main() {
    violencePersp = ProjMat[2][3] < -0.5 ? 1.0 : 0.0;  // VIOLENCE
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, violence_skin_light(UV2));  // VIOLENCE: 인형 표시 번호를 뺀 밝기
    overlayColor = texelFetch(Sampler1, UV1, 0);
    violenceFlash = violence_flash_state(Sampler2, ProjMat);  // VIOLENCE
    #else
    violenceFlash = vec2(0.0);  // VIOLENCE
    #endif

    texCoord0 = UV0;
    if (violencePersp > 0.5 && violence_puppet_hidden(UV2, Position)) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);  // VIOLENCE: 1인칭 자기 인형 숨김
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}
